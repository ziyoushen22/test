package com.iotek.dao;

import com.iotek.domain.User;

/**
 * Created by jun on 2016/9/6.
 */
public interface UserDao {
    User findUserByUsername(String name);
}
