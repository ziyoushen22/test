package com.iotek.dao;

import com.iotek.domain.User;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by jun on 2016/9/6.
 */
@Repository(value = "userDaoImpl")
public class UserDaoImpl implements UserDao {
    private HibernateTemplate hibernateTemplate;
    public void setSessionFactory(SessionFactory sessionFactory) {
        hibernateTemplate = new HibernateTemplate(sessionFactory);
    }

    @Override
    public User findUserByUsername(String name){
        String hql = "from User where userName = ?";
        List<User> users = (List<User>) hibernateTemplate.find(hql,name);
        return null!= users?users.get(0):null;
    }
}
