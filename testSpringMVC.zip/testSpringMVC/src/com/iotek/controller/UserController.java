package com.iotek.controller;

import com.iotek.biz.UserService;
import com.iotek.domain.User;
import com.iotek.exception.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpSession;

/**
 * Created by jun on 2016/9/6.
 */
@Controller
public class UserController {
    private UserService userService;

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @RequestMapping(value = "/log", method = RequestMethod.POST)
    public String login(User user, ModelMap model, HttpSession session) {
        User user1=null;
        try{
            user1 = userService.loadUserByUsername(user.getUserName());
        } catch (UsernameNotFoundException e) {
            return "exception";
        }
        if (null != user1) {
            session.setAttribute("user",user1);
            model.addAttribute("success","��¼�ɹ�");
            return "loginSuccess";
        }
        model.addAttribute("error","�û������������");
        return "index";
    }
}
