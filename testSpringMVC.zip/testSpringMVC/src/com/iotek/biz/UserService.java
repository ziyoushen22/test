package com.iotek.biz;

import com.iotek.domain.User;
import com.iotek.exception.UsernameNotFoundException;

/**
 * Created by MAO on 2016/12/28.
 */
public interface UserService {
    User loadUserByUsername(String name) throws UsernameNotFoundException;
}
