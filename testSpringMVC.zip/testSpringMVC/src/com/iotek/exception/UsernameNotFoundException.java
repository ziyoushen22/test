package com.iotek.exception;

/**
 * Created by MAO on 2016/12/28.
 */
public class UsernameNotFoundException extends Exception {
    public UsernameNotFoundException(String message) {
        super(message);
    }
}
