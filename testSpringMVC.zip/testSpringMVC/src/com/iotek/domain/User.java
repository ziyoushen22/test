package com.iotek.domain;

import javax.persistence.*;

/**
 * Created by vitme on 2016/10/15.
 */
@Entity
@Table(name = "user",catalog = "test")
public class User {
    private String userName;
    private String userPass;
    private Set<GrantedAuthority> roles;

    public User() {
    }

    public User(String userName, String userPass, Set<GrantedAuthority> roles) {
        this.userName=userName;
        this.userPass=userPass;
        this.roles=roles;
    }

    @Id
    @Column(name = "username")
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    @Column(name = "userpass")
    public void setUserPass(String userPass) {
        this.userPass = userPass;
    }

    public String getUserPass() {
        return userPass;
    }

    @OneToMany
    @JoinColumn(name="roles")
    public Set<GrantedAuthority> getRoles() {
        return roles;
    }

    public void setRoles(Set<GrantedAuthority> roles) {
        this.roles = roles;
    }

    @Override
    public String toString() {
        return "User{" +
                "userName='" + userName + '\'' +
                ", userPass='" + userPass + '\'' +
                ", roles=" + roles +
                '}';
    }
}
